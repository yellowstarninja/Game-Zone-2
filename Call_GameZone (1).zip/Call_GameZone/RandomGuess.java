/**
* Assigns whether a number too low, too high, or tie.
*
* Brian Call
* 12.15.23
*/
import java.util.Scanner; //defines import statemnets
import java.util.Date;
import javax.swing.JOptionPane;
public class RandomGuess
{
   public static void main(String[] args)
   {
      OpenBox();//calls open box
      
      String name = JOptionPane.showInputDialog(null, "What's your name?");//asks name
      JOptionPane.showMessageDialog(null, "Nice to meet you " + name + "! The current date is " + new Date());//displays name and date
      
      JOptionPane.showMessageDialog(null,
         "Before pressing OK try to guess my number between 1 and 10"); //instructions
      
      String guessStr = JOptionPane.showInputDialog(null, "Guess the number!");//asks for guess
      int guess = Integer.parseInt(guessStr);   //parses guess
      
      int number = (1 + (int)(Math.random() * 10));//generates number

      if(guess > number)//assess if too high
      {
          TooHigh();//runs box if true
      }
      else if(guess < number)//assess if too low
      {
          TooLow();//runs box if true
      }    
      else//else has to be equal
      {
          Equal();//runs if equal
      }
      
      JOptionPane.showMessageDialog(null,
          "The number is " + number + ".");//displays number
      
      CloseBox();//displays close
   }
   
   public static void OpenBox()//defines box method
   {
       System.out.println("--------------------------");//opening box
       System.out.println("=                        =");
       System.out.println("=       Welcome to       =");
       System.out.println("= Random Number Guesser! =");
       System.out.println("=                        =");
       System.out.println("=       By Ding-es       =");
       System.out.println("=                        =");
       System.out.println("--------------------------");

   }
   
      public static void CloseBox()//defines closing box method
   {
       System.out.println("--------------------------");//closing box
       System.out.println("=                        =");
       System.out.println("=   Thanks for playing   =");
       System.out.println("= Random Number Guesser! =");
       System.out.println("=                        =");
       System.out.println("=       By Ding-es       =");
       System.out.println("=                        =");
       System.out.println("--------------------------");

   }
   
   public static void TooHigh()//defines too high text art
   {
       
       System.out.println("████████╗░█████╗░░█████╗░  ██╗░░██╗██╗░██████╗░██╗░░██╗░░░░░░░░░");//high text art
       System.out.println("╚══██╔══╝██╔══██╗██╔══██╗  ██║░░██║██║██╔════╝░██║░░██║░░░░░░░░░");
       System.out.println("░░░██║░░░██║░░██║██║░░██║  ███████║██║██║░░██╗░███████║░░░░░░░░░");
       System.out.println("░░░██║░░░██║░░██║██║░░██║  ██╔══██║██║██║░░╚██╗██╔══██║░░░░░░░░░");
       System.out.println("░░░██║░░░╚█████╔╝╚█████╔╝  ██║░░██║██║╚██████╔╝██║░░██║██╗██╗██╗");
       System.out.println("░░░╚═╝░░░░╚════╝░░╚════╝░  ╚═╝░░╚═╝╚═╝░╚═════╝░╚═╝░░╚═╝╚═╝╚═╝╚═╝");
   }
   
   public static void TooLow()//defines too low text art
   {
       
       System.out.println("████████╗░█████╗░░█████╗░  ██╗░░░░░░█████╗░░██╗░░░░░░░██╗░░░░░░░░░");//too low text art
       System.out.println("╚══██╔══╝██╔══██╗██╔══██╗  ██║░░░░░██╔══██╗░██║░░██╗░░██║░░░░░░░░░");
       System.out.println("░░░██║░░░██║░░██║██║░░██║  ██║░░░░░██║░░██║░╚██╗████╗██╔╝░░░░░░░░░");
       System.out.println("░░░██║░░░██║░░██║██║░░██║  ██║░░░░░██║░░██║░░████╔═████║░░░░░░░░░░");
       System.out.println("░░░██║░░░╚█████╔╝╚█████╔╝  ███████╗╚█████╔╝░░╚██╔╝░╚██╔╝░██╗██╗██╗");
       System.out.println("░░░╚═╝░░░░╚════╝░░╚════╝░  ╚══════╝░╚════╝░░░░╚═╝░░░╚═╝░░╚═╝╚═╝╚═╝");
   }
   
   public static void Equal()//defines tie text art
   {
       
       System.out.println("████████╗██╗███████╗██╗");//tie text art
       System.out.println("╚══██╔══╝██║██╔════╝██║");
       System.out.println("░░░██║░░░██║█████╗░░██║");
       System.out.println("░░░██║░░░██║██╔══╝░░╚═╝");
       System.out.println("░░░██║░░░██║███████╗██╗");
       System.out.println("░░░╚═╝░░░╚═╝╚══════╝╚═╝");
   }
}